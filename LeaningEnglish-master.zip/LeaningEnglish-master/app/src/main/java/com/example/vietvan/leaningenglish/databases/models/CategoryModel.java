package com.example.vietvan.leaningenglish.databases.models;

public class CategoryModel {
    public String name, color;

    public CategoryModel(String name, String color) {
        this.name = name;
        this.color = color;
    }
}
