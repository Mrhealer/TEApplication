package com.example.vietvan.leaningenglish.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.vietvan.leaningenglish.R;

public class ReviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
    }

}
