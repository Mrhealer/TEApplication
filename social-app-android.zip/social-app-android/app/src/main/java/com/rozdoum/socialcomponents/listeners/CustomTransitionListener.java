package com.rozdoum.socialcomponents.listeners;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.transition.Transition;

/**
 * Created by alexey on 05.04.17.
 */

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class CustomTransitionListener implements Transition.TransitionListener {

    @Override
    public void onTransitionStart(Transition transition) {

    }

    @Override
    public void onTransitionEnd(Transition transition) {

    }

    @Override
    public void onTransitionCancel(Transition transition) {

    }

    @Override
    public void onTransitionPause(Transition transition) {

    }

    @Override
    public void onTransitionResume(Transition transition) {

    }
}
